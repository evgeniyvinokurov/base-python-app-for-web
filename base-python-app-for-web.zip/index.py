from bottle import default_app, run

import router

application = default_app()
application.run()

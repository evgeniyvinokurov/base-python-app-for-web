from bottle import redirect, route, view, post, request, get, response, auth_basic
from bottle import static_file


from projects.feedback.codes.feedback import router


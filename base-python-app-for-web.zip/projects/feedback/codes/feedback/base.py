basexmlpath = "./xml"

feedback = basexmlpath + "/feedback/"

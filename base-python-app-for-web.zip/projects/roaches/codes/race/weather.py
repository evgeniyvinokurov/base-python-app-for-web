import random

def get():
    return random.randint(10,110)
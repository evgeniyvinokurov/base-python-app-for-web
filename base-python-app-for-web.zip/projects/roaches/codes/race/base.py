basexmlpath = "./xml"

roachespath = basexmlpath + "/roaches/"
racepath = basexmlpath + "/race/"
entriespath = basexmlpath + "/entries/"


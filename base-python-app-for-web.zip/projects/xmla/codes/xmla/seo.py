from ..classes.xmlaxmllib import XmlaXmlLib

def getseo():    
    return XmlaXmlLib.getconfig()
    

Форма обратной связи  
  
Как часть приложения bottle загружает код из подпапки  
файлы проекта:  
 - feedback-src - фронтенд формы обратной на vue.js  
 - projects/feedback - python код формы обратной связи  
 - views/feedback.html - вью формы обратной связи для bottle.py  
 - static/js, static/css - фронтенд код и стили фомы обратной связи  
 - сборка фронтенда проекта: node ./node_modules/webpack/bin/webpack.js  

 
